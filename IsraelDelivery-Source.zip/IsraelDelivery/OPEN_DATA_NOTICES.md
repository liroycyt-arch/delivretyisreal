# הודעות רישוי וייחוס

## נתוני מפה

נתוני הרחובות, המבנים ונקודות העניין המקומיים מבוססים על OpenStreetMap ומסופקים תחת רישיון Open Database License (ODbL) 1.0.

ייחוס: © תורמי OpenStreetMap. פרטי זכויות ורישיון: https://www.openstreetmap.org/copyright

הנתונים הגולמיים שנכללו במאגר נמצאים ב־`data/tel_aviv_osm_extract.json`; תצוגת המשחק והנתונים המעובדים נמצאים ב־`data/tel_aviv_map.json`. אם מפיצים מאגר נגזר מעודכן, יש לבחון את תנאי ODbL ולפרסם את המאגר הנגזר בהתאם לתנאים.

המשחק מציג ייחוס OpenStreetMap במסך הפתיחה ובממשק המפה.

## גופן

ממשק המשחק כולל את DejaVu Sans, גופן חופשי שמופץ ברישיון Bitstream Vera / DejaVu. הודעת הרישיון מצורפת בפרויקט ב־`assets/fonts/LICENSE-DejaVu.txt` ומופצת בהתקנה בשם `DejaVu-LICENSE.txt`.

## נכסים מקוריים

הסמל, מודלי האופניים/הקטנוע ודמויות המשחק נוצרו לצורך הפרויקט מתוך צורות בסיס של Godot. אין בפרויקט לוגואים רשמיים של חברות משלוחים.

## Godot Engine

המשחק משתמש ב־Godot Engine 4.7.2, המופץ ברישיון MIT. נוסח הרישיון מצורף ב־`THIRD_PARTY/Godot-LICENSE.txt` ומופץ בהתקנה בשם `Godot-LICENSE.txt`. מקור: https://github.com/godotengine/godot/tree/4.7.2-stable
