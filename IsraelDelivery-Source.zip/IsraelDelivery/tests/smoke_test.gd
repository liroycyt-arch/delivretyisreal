extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var game: Node = load("res://scenes/main.tscn").instantiate()
	root.add_child(game)
	await process_frame
	if game.map_data.get("roads", []).size() < 1000:
		_fail("מפת הרחובות לא נטענה")
		return
	game.order_name_input.text = "בדיקת מערכת"
	game.company_picker.select(1)
	game.vehicle_picker.select(1)
	game._start_new_game()
	await process_frame
	if game.mission_state != 0 or game.rider.vehicle_name != "קורקינט חשמלי":
		_fail("התחלת משחק או בחירת כלי לא פעלה")
		return
	if game.route_active:
		_fail("הצעה חדשה הפעילה ניווט לפני שהשליח אישר אותה")
		return
	game._accept_order()
	if game.mission_state != 1:
		_fail("קבלת הזמנה לא שינתה את מצב המשימה")
		return
	if not game.route_active or game.active_route.size() < 2:
		_fail("לא חושב מסלול רחובות לאיסוף")
		return
	game.rider.global_position = Vector3(game.pickup_position.x, 0.05, game.pickup_position.y)
	game._interact()
	if game.mission_state != 2 or not game.rider.carrying_package:
		_fail("איסוף המשלוח לא התקדם לשלב המסירה")
		return
	game.rider.global_position = Vector3(game.dropoff_position.x, 0.05, game.dropoff_position.y)
	game._interact()
	if game.mission_state != 3 or game.deliveries_done != 1 or game.rider.carrying_package or game.delivery_history.size() != 1:
		_fail("מסירה לא הושלמה")
		return
	var paid_balance: int = game.balance
	game._deliver_order()
	if game.balance != paid_balance or game.deliveries_done != 1:
		_fail("המערכת אפשרה תשלום כפול")
		return
	game._save_game()
	if not FileAccess.file_exists("user://israel_delivery_save.json"):
		_fail("קובץ השמירה לא נוצר")
		return
	var saved: Variant = JSON.parse_string(FileAccess.get_file_as_string("user://israel_delivery_save.json"))
	if not saved is Dictionary or int(saved.get("balance",0)) != paid_balance:
		_fail("נתוני הבנק לא נשמרו כראוי")
		return
	game._set_minimap_enabled(false)
	if game.mini_map.get_parent().visible:
		_fail("הגדרת המפה הקטנה לא פעלה")
		return
	game._set_minimap_enabled(true)
	game._set_first_person(true)
	if not game.rider.first_person:
		_fail("הגדרת המצלמה לא פעלה")
		return
	game._set_first_person(false)
	game._toggle_phone("היסטוריה")
	game._phone_tab("הודעות")
	if game.phone_page != "הודעות" or game.phone_body.get_child_count() == 0:
		_fail("מסכי ההיסטוריה וההודעות אינם פעילים")
		return
	game._close_phone()
	game._return_to_title()
	game._continue_game()
	if game.balance != paid_balance or game.deliveries_done != 1 or game.delivery_history.size() != 1:
		_fail("המשך משחק לא שיחזר את נתוני ההתקדמות")
		return
	print("בדיקה עברה: מפה, ניווט רחובות, הצעה/קבלה/איסוף/מסירה, תיק תלת־ממדי, תשלום יחיד, היסטוריה, הודעות, הגדרות ושמירה/המשך.")
	quit(0)

func _fail(message: String) -> void:
	push_error(message)
	quit(1)
