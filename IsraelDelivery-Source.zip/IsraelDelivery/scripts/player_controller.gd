extends CharacterBody3D
class_name DeliveryRider

var max_speed_kph := 25.0
var acceleration := 5.0
var turn_rate := 1.65
var vehicle_name := "אופניים חשמליים"
var company_name := "שליח עצמאי"
var company_color := Color("e6af32")
var speed_kph := 0.0
var controls_enabled := false
var first_person := false
var _bike_visual: Node3D
var _camera_third: Camera3D
var _camera_first: Camera3D
var _pedal_left: Node3D
var _pedal_right: Node3D
var _cargo_visual: Node3D
var carrying_package := false

func _ready() -> void:
	name = "השליח"
	_add_collision()
	_build_vehicle()
	_build_rider()
	_build_cameras()

func configure(vehicle: String, company: String) -> void:
	vehicle_name = vehicle
	company_name = company
	match vehicle:
		"קורקינט חשמלי":
			max_speed_kph = 30.0
			acceleration = 7.5
			turn_rate = 1.9
		"קטנוע ישן וחצי שבור":
			max_speed_kph = 25.0
			acceleration = 4.0
			turn_rate = 1.35
		_:
			max_speed_kph = 25.0
			acceleration = 5.4
			turn_rate = 1.6
	company_color = Color("e8b625") if company == "משלוחה" else (Color("178cb5") if company == "וולט" else Color("58616a"))
	if is_inside_tree() and _bike_visual != null:
		_bike_visual.queue_free()
		for child in get_children():
			if child.name == "רוכב" or child == _pedal_left or child == _pedal_right:
				child.queue_free()
		_build_vehicle()
		_build_rider()

func _physics_process(delta: float) -> void:
	if controls_enabled:
		var throttle := float(Input.is_key_pressed(KEY_W)) - float(Input.is_key_pressed(KEY_S))
		var steering := float(Input.is_key_pressed(KEY_A)) - float(Input.is_key_pressed(KEY_D))
		var braking := Input.is_key_pressed(KEY_SPACE)
		var target_speed := max_speed_kph * throttle
		if braking:
			target_speed = 0.0
		var blend := clampf(acceleration * delta / 3.6, 0.0, 1.0)
		if braking:
			blend = clampf(12.0 * delta, 0.0, 1.0)
		speed_kph = lerpf(speed_kph, target_speed, blend)
		var normalized_speed := absf(speed_kph) / maxf(max_speed_kph, 1.0)
		if absf(speed_kph) > 0.1:
			rotation.y += steering * turn_rate * delta * (0.25 + normalized_speed * 0.9) * (1.0 if speed_kph >= 0.0 else -1.0)
		var forward := -global_transform.basis.z
		velocity.x = forward.x * speed_kph / 3.6
		velocity.z = forward.z * speed_kph / 3.6
	else:
		velocity.x = move_toward(velocity.x, 0.0, 2.5 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 2.5 * delta)
		velocity.y = 0.0
		move_and_slide()
		return
	if not is_on_floor():
		velocity.y -= 18.0 * delta
	else:
		velocity.y = -0.2
	move_and_slide()
	if _pedal_left != null:
		var pedal_turn := speed_kph * delta * 0.11
		_pedal_left.rotation.x += pedal_turn
		_pedal_right.rotation.x -= pedal_turn

func set_first_person(enabled: bool) -> void:
	first_person = enabled
	if _camera_first:
		_camera_first.current = enabled
	if _camera_third:
		_camera_third.current = not enabled

func set_carrying_package(enabled: bool) -> void:
	carrying_package = enabled
	if _cargo_visual:
		_cargo_visual.visible = enabled

func _add_collision() -> void:
	var shape_node := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.34
	capsule.height = 1.75
	shape_node.shape = capsule
	shape_node.position.y = 0.9
	add_child(shape_node)

func _build_cameras() -> void:
	var third_pivot := Node3D.new()
	third_pivot.position = Vector3(0, 1.7, 0)
	add_child(third_pivot)
	_camera_third = Camera3D.new()
	_camera_third.position = Vector3(0, 2.5, 7.1)
	_camera_third.rotation_degrees.x = -14
	third_pivot.add_child(_camera_third)
	_camera_first = Camera3D.new()
	_camera_first.position = Vector3(0, 1.73, -0.2)
	_camera_first.rotation_degrees.x = -2
	add_child(_camera_first)
	_camera_third.current = true

func _build_vehicle() -> void:
	_bike_visual = Node3D.new()
	_bike_visual.name = "כלי התחבורה"
	add_child(_bike_visual)
	var frame_mat := _material(Color("dfaa34"), 0.48)
	var dark_mat := _material(Color("25292b"), 0.58)
	var metal_mat := _material(Color("a6afb1"), 0.35)
	if vehicle_name == "קורקינט חשמלי":
		_add_box(_bike_visual, Vector3(0.18,0.07,1.05), Vector3(0,0.22,0), dark_mat)
		_add_rod(_bike_visual, Vector3(0,0.25,-0.42), Vector3(0,1.13,-0.45), 0.055, frame_mat)
		_add_rod(_bike_visual, Vector3(-0.34,1.12,-0.45), Vector3(0.34,1.12,-0.45), 0.045, dark_mat)
		_add_wheel(_bike_visual, Vector3(0,0.3,-0.55), 0.24, dark_mat)
		_add_wheel(_bike_visual, Vector3(0,0.3,0.55), 0.24, dark_mat)
	elif vehicle_name == "קטנוע ישן וחצי שבור":
		_add_box(_bike_visual, Vector3(0.62,0.52,0.9), Vector3(0,0.68,-0.05), _material(Color("858176"), 0.9))
		_add_box(_bike_visual, Vector3(0.48,0.38,0.52), Vector3(0,0.88,0.18), _material(Color("383a39"), 0.76))
		_add_rod(_bike_visual, Vector3(0,0.55,-0.48), Vector3(0,1.2,-0.55), 0.065, metal_mat)
		_add_rod(_bike_visual, Vector3(-0.42,1.18,-0.55), Vector3(0.42,1.18,-0.55), 0.05, dark_mat)
		_add_wheel(_bike_visual, Vector3(0,0.35,-0.62), 0.32, dark_mat)
		_add_wheel(_bike_visual, Vector3(0,0.35,0.66), 0.32, dark_mat)
		_add_box(_bike_visual, Vector3(0.05,0.035,0.20), Vector3(0.29,0.96,-0.04), _material(Color("3e3129"), 0.8))
	else:
		_add_rod(_bike_visual, Vector3(0,0.45,-0.62), Vector3(-0.34,0.45,0.1), 0.045, frame_mat)
		_add_rod(_bike_visual, Vector3(-0.34,0.45,0.1), Vector3(0,0.45,0.65), 0.045, frame_mat)
		_add_rod(_bike_visual, Vector3(0,0.45,-0.62), Vector3(0,0.93,0.06), 0.045, frame_mat)
		_add_rod(_bike_visual, Vector3(0,0.93,0.06), Vector3(0,0.45,0.65), 0.045, frame_mat)
		_add_rod(_bike_visual, Vector3(0,0.93,0.06), Vector3(-0.3,0.93,0.06), 0.06, dark_mat)
		_add_rod(_bike_visual, Vector3(0,0.93,0.06), Vector3(0,1.13,-0.57), 0.045, metal_mat)
		_add_rod(_bike_visual, Vector3(-0.35,1.13,-0.57), Vector3(0.35,1.13,-0.57), 0.045, dark_mat)
		_add_wheel(_bike_visual, Vector3(0,0.45,-0.65), 0.42, dark_mat)
		_add_wheel(_bike_visual, Vector3(0,0.45,0.67), 0.42, dark_mat)
		_add_box(_bike_visual, Vector3(0.38,0.22,0.42), Vector3(0,1.16,0.12), _material(company_color, 0.5))
	_cargo_visual = Node3D.new()
	_cargo_visual.name = "תיק משלוח"
	_cargo_visual.position = Vector3(0,1.23,0.62)
	_bike_visual.add_child(_cargo_visual)
	var bag_mat := _material(Color("e5b33f"),0.56)
	var trim_mat := _material(Color("20282b"),0.72)
	_add_box(_cargo_visual,Vector3(0.50,0.43,0.34),Vector3.ZERO,bag_mat)
	_add_box(_cargo_visual,Vector3(0.53,0.07,0.37),Vector3(0,0.23,0),trim_mat)
	_add_box(_cargo_visual,Vector3(0.07,0.42,0.36),Vector3(-0.21,0,0),trim_mat)
	_add_box(_cargo_visual,Vector3(0.07,0.42,0.36),Vector3(0.21,0,0),trim_mat)
	var package_label := Label3D.new()
	package_label.text = "משלוח"
	package_label.position = Vector3(0,0,0.18)
	package_label.rotation.y = PI
	package_label.font_size = 24
	package_label.pixel_size = 0.004
	package_label.modulate = Color("fff2c9")
	package_label.outline_size = 4
	_cargo_visual.add_child(package_label)
	_cargo_visual.visible = carrying_package

func _build_rider() -> void:
	var human := Node3D.new()
	human.name = "רוכב"
	add_child(human)
	var jacket := _material(company_color, 0.82)
	var trousers := _material(Color("343a3d"), 0.88)
	var skin := _material(Color("c58b69"), 0.9)
	var helmet_mat := _material(Color("e8e3d8"), 0.35)
	var chest := _add_capsule(human, 0.30, 0.74, Vector3(0,1.52,-0.03), jacket)
	chest.rotation.x = -0.25
	_add_sphere(human, Vector3(0,2.05,-0.07), Vector3(0.23,0.25,0.23), skin)
	_add_sphere(human, Vector3(0,2.18,-0.07), Vector3(0.255,0.12,0.255), helmet_mat)
	_add_box(human, Vector3(0.42,0.48,0.17), Vector3(0,1.56,-0.42), _material(Color("292e30"), 0.88))
	_add_rod(human, Vector3(-0.18,1.75,-0.14), Vector3(-0.26,1.2,-0.53), 0.09, jacket)
	_add_rod(human, Vector3(0.18,1.75,-0.14), Vector3(0.26,1.2,-0.53), 0.09, jacket)
	_add_sphere(human, Vector3(-0.26,1.18,-0.53), Vector3(0.075,0.07,0.075), skin)
	_add_sphere(human, Vector3(0.26,1.18,-0.53), Vector3(0.075,0.07,0.075), skin)
	_add_rod(human, Vector3(-0.15,1.33,0.04), Vector3(-0.2,0.77,0.25), 0.12, trousers)
	_add_rod(human, Vector3(-0.2,0.77,0.25), Vector3(-0.22,0.48,0.38), 0.10, trousers)
	_add_rod(human, Vector3(0.15,1.33,0.04), Vector3(0.2,0.77,0.25), 0.12, trousers)
	_add_rod(human, Vector3(0.2,0.77,0.25), Vector3(0.22,0.48,0.38), 0.10, trousers)
	var brand := Label3D.new()
	brand.text = "משלוחה" if company_name == "משלוחה" else ("וולט" if company_name == "וולט" else "שליח")
	brand.font_size = 28
	brand.pixel_size = 0.0045
	brand.position = Vector3(0,1.56,-0.205)
	brand.rotation.y = PI
	brand.modulate = Color("202426")
	brand.outline_size = 3
	brand.outline_modulate = Color(1,1,1,0.65)
	human.add_child(brand)
	_pedal_left = Node3D.new()
	_pedal_left.position = Vector3(-0.22,0.47,0.38)
	_pedal_right = Node3D.new()
	_pedal_right.position = Vector3(0.22,0.47,0.38)
	add_child(_pedal_left)
	add_child(_pedal_right)

func _recolor_rider() -> void:
	for child in get_children():
		if child is MeshInstance3D:
			var mat := StandardMaterial3D.new()
			mat.albedo_color = company_color
			child.material_override = mat

func _add_wheel(parent: Node3D, at: Vector3, radius: float, mat: Material) -> void:
	var wheel := MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = radius * 0.84
	torus.outer_radius = radius
	wheel.mesh = torus
	wheel.rotation.z = PI * 0.5
	wheel.position = at
	wheel.material_override = mat
	parent.add_child(wheel)
	var hub := _add_cylinder(parent, Vector3(0.055, radius * 0.25, radius * 0.25), at, mat)
	hub.rotation.z = PI * 0.5

func _add_rod(parent: Node3D, a: Vector3, b: Vector3, radius: float, mat: Material) -> void:
	var rod := MeshInstance3D.new()
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = radius
	cylinder.bottom_radius = radius
	cylinder.height = a.distance_to(b)
	rod.mesh = cylinder
	rod.position = (a + b) * 0.5
	rod.quaternion = Quaternion(Vector3.UP, (b - a).normalized())
	rod.material_override = mat
	parent.add_child(rod)

func _add_box(parent: Node3D, size: Vector3, at: Vector3, mat: Material) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	mesh.position = at
	mesh.material_override = mat
	parent.add_child(mesh)
	return mesh

func _add_cylinder(parent: Node3D, size: Vector3, at: Vector3, mat: Material) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = size.x
	cylinder.bottom_radius = size.x
	cylinder.height = size.y
	mesh.mesh = cylinder
	mesh.position = at
	mesh.material_override = mat
	parent.add_child(mesh)
	return mesh

func _add_sphere(parent: Node3D, at: Vector3, scale: Vector3, mat: Material) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 0.5
	sphere.height = 1.0
	mesh.mesh = sphere
	mesh.position = at
	mesh.scale = scale
	mesh.material_override = mat
	parent.add_child(mesh)
	return mesh

func _add_capsule(parent: Node3D, radius: float, height: float, at: Vector3, mat: Material) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	var capsule := CapsuleMesh.new()
	capsule.radius = radius
	capsule.height = height
	mesh.mesh = capsule
	mesh.position = at
	mesh.material_override = mat
	parent.add_child(mesh)
	return mesh

func _material(color: Color, roughness: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	return material
