extends Node3D

const MapBuilder = preload("res://scripts/map_builder.gd")
const RiderScript = preload("res://scripts/player_controller.gd")
const MapPanelScript = preload("res://scripts/map_panel.gd")
const SAVE_PATH := "user://israel_delivery_save.json"
const MAP_PATH := "res://data/tel_aviv_map.json"

var map_data: Dictionary = {}
var rider: DeliveryRider
var graph_adj: Array = []
var graph_nodes: Array = []
var active_route: Array[Vector2] = []
var route_names: Array[String] = []
var route_target := Vector2.ZERO
var route_active := false
var navigation_label := ""
var pickup_position := Vector2.ZERO
var dropoff_position := Vector2.ZERO
var mission_state := 0 # 0 offer, 1 ride to pickup, 2 ride to customer, 3 completed
var mission_id := 0
var mission_restaurant := ""
var mission_pay := 0
var mission_dist := 0.0
var paid_ids: Dictionary = {}
var player_name := "שליח חדש"
var company := "שליח עצמאי"
var vehicle := "אופניים חשמליים"
var balance := 120
var total_earned := 0
var deliveries_done := 0
var deliveries_declined := 0
var bank_ledger: Array[Dictionary] = []
var delivery_history: Array[Dictionary] = []
var app_messages: Array[String] = []
var show_minimap := true
var first_person := false
var game_started := false
var is_phone_open := false
var phone_page := "משלוחים"
var is_paused := false
var saved_position := Vector3.ZERO
var toast_timer := 0.0
var autosave_timer := 0.0
var target_marker: Node3D
var ui_root: Control
var title_overlay: Control
var hud: Control
var hud_info: Label
var hud_prompt: Label
var hud_balance: Label
var hud_distance: Label
var mini_map: DeliveryMapPanel
var phone_overlay: Control
var phone_card: PanelContainer
var phone_body: VBoxContainer
var pause_overlay: Control
var order_name_input: LineEdit
var company_picker: OptionButton
var vehicle_picker: OptionButton
var toast_label: Label
var help_label: Label

func _ready() -> void:
	DisplayServer.window_set_title("משלוחים בישראל")
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	_load_map()
	MapBuilder.build(self, map_data)
	_build_graph()
	_create_rider()
	_build_ui()
	_show_title()

func _process(delta: float) -> void:
	if game_started and not is_paused:
		autosave_timer += delta
		if autosave_timer >= 15.0:
			autosave_timer = 0.0
			_save_game()
	if toast_timer > 0.0:
		toast_timer -= delta
		if toast_timer <= 0.0 and toast_label:
			toast_label.visible = false
	if game_started and rider:
		_update_hud()
		_update_minimap()
		_update_target_marker()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		_save_game()
		get_tree().quit()

func _unhandled_input(event: InputEvent) -> void:
	if not game_started:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_P:
				_toggle_phone("משלוחים")
				get_viewport().set_input_as_handled()
			KEY_M:
				_toggle_phone("מפה")
				get_viewport().set_input_as_handled()
			KEY_C:
				first_person = not rider.first_person
				rider.set_first_person(first_person)
				_save_game()
				_notify("המצלמה הוחלפה")
				get_viewport().set_input_as_handled()
			KEY_E:
				_interact()
				get_viewport().set_input_as_handled()
			KEY_ESCAPE:
				if is_phone_open:
					_toggle_phone(phone_page)
				else:
					_toggle_pause()
				get_viewport().set_input_as_handled()

func _load_map() -> void:
	if not FileAccess.file_exists(MAP_PATH):
		push_error("קובץ המפה המקומי חסר")
		map_data = {"roads": [], "buildings": [], "pois": [], "graph_nodes": [], "graph_edges": []}
		return
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(MAP_PATH))
	if parsed is Dictionary:
		map_data = parsed
	else:
		push_error("קובץ המפה המקומי אינו תקין")
		map_data = {"roads": [], "buildings": [], "pois": [], "graph_nodes": [], "graph_edges": []}

func _build_graph() -> void:
	graph_nodes = map_data.get("graph_nodes", [])
	graph_adj.resize(graph_nodes.size())
	for i in range(graph_adj.size()):
		graph_adj[i] = []
	for edge in map_data.get("graph_edges", []):
		var a := int(edge[0]); var b := int(edge[1])
		if a < 0 or b < 0 or a >= graph_adj.size() or b >= graph_adj.size():
			continue
		graph_adj[a].append({"to": b, "distance": float(edge[3]), "name": str(edge[2])})

func _create_rider() -> void:
	rider = RiderScript.new()
	rider.configure(vehicle, company)
	var start_index := _nearest_node(Vector2.ZERO)
	if start_index >= 0:
		var start: Array = graph_nodes[start_index]
		rider.position = Vector3(float(start[0]), 0.04, float(start[1]))
	else:
		rider.position = Vector3(0,0.04,0)
	add_child(rider)

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)
	ui_root = Control.new()
	ui_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.layout_direction = Control.LAYOUT_DIRECTION_RTL
	layer.add_child(ui_root)
	_build_title_ui()
	_build_hud()
	_build_phone()
	_build_pause_ui()
	_build_toast()

func _build_title_ui() -> void:
	title_overlay = Control.new()
	title_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(title_overlay)
	var back := ColorRect.new()
	back.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	back.color = Color("101d22")
	title_overlay.add_child(back)
	var accent := ColorRect.new()
	accent.position = Vector2(0,0)
	accent.size = Vector2(12,900)
	accent.color = Color("e5b43d")
	title_overlay.add_child(accent)
	var panel := _make_card(title_overlay, Vector2(420,605), Vector2(510,145))
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 14)
	panel.add_child(content)
	var badge := Label.new()
	badge.text = "  תל אביב · סימולטור שליחויות  "
	badge.add_theme_font_size_override("font_size", 15)
	badge.modulate = Color("e9bf55")
	badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	content.add_child(badge)
	var title := Label.new()
	title.text = "משלוחים בישראל"
	title.add_theme_font_size_override("font_size", 38)
	title.modulate = Color("f6f3e9")
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	content.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "יוצאים לרחוב. אוספים. מוסרים. מרוויחים."
	subtitle.add_theme_font_size_override("font_size", 15)
	subtitle.modulate = Color("b8c5c5")
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	content.add_child(subtitle)
	content.add_child(_separator())
	var name_label := _label("שם השליח", 15, Color("e7ece7"))
	content.add_child(name_label)
	order_name_input = LineEdit.new()
	order_name_input.placeholder_text = "איך קוראים לך?"
	order_name_input.text = player_name if player_name != "שליח חדש" else ""
	order_name_input.max_length = 20
	order_name_input.custom_minimum_size.y = 42
	content.add_child(order_name_input)
	content.add_child(_label("חברת המשלוחים", 15, Color("e7ece7")))
	company_picker = OptionButton.new()
	company_picker.custom_minimum_size.y = 42
	for item in ["שליח עצמאי", "משלוחה", "וולט"]:
		company_picker.add_item(item)
	content.add_child(company_picker)
	content.add_child(_label("כלי התחבורה", 15, Color("e7ece7")))
	vehicle_picker = OptionButton.new()
	vehicle_picker.custom_minimum_size.y = 42
	for item in ["אופניים חשמליים", "קורקינט חשמלי", "קטנוע ישן וחצי שבור"]:
		vehicle_picker.add_item(item)
	content.add_child(vehicle_picker)
	var start_btn := _button("משחק חדש", Callable(self, "_start_new_game"), true)
	content.add_child(start_btn)
	var continue_btn := _button("המשך משחק שמור", Callable(self, "_continue_game"), false)
	content.add_child(continue_btn)
	continue_btn.disabled = not FileAccess.file_exists(SAVE_PATH)
	var attribution := Label.new()
	attribution.text = "נתוני רחובות: OpenStreetMap · © תורמי OpenStreetMap · ODbL"
	attribution.add_theme_font_size_override("font_size", 10)
	attribution.modulate = Color("839595")
	attribution.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	content.add_child(attribution)

func _build_hud() -> void:
	hud = Control.new()
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(hud)
	var top := _make_card(hud, Vector2(300,112), Vector2(22,22))
	hud_info = _label("מוכן ליציאה", 18, Color("f6f3e9"))
	top.add_child(hud_info)
	hud_balance = _label("יתרה: 120 ₪", 16, Color("e9bf55"))
	top.add_child(hud_balance)
	hud_distance = _label("המתן להצעה בטלפון", 13, Color("b8c5c5"))
	top.add_child(hud_distance)
	var map_card := _make_card(hud, Vector2(250,190), Vector2(1165,22))
	mini_map = MapPanelScript.new()
	mini_map.custom_minimum_size = Vector2(218,138)
	mini_map.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	map_card.add_child(mini_map)
	mini_map.configure(map_data)
	var attribution := _label("OpenStreetMap · ODbL", 9, Color("aebdbd"))
	attribution.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	map_card.add_child(attribution)
	hud_prompt = Label.new()
	hud_prompt.anchor_left = 0.2; hud_prompt.anchor_right = 0.8
	hud_prompt.anchor_top = 0.80; hud_prompt.anchor_bottom = 0.90
	hud_prompt.offset_left = 0; hud_prompt.offset_right = 0
	hud_prompt.offset_top = 0; hud_prompt.offset_bottom = 0
	hud_prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hud_prompt.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	hud_prompt.add_theme_font_size_override("font_size", 22)
	hud_prompt.modulate = Color("fff4d3")
	hud.add_child(hud_prompt)
	help_label = Label.new()
	help_label.anchor_left = 0.0; help_label.anchor_right = 1.0
	help_label.anchor_top = 0.94; help_label.anchor_bottom = 1.0
	help_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	help_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	help_label.text = "W/S נסיעה · A/D פנייה · רווח בלימה · E אינטראקציה · P טלפון · M מפה · C מצלמה · Esc השהיה"
	help_label.add_theme_font_size_override("font_size", 13)
	help_label.modulate = Color("d4dddc")
	hud.add_child(help_label)
	hud.visible = false

func _build_phone() -> void:
	phone_overlay = Control.new()
	phone_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(phone_overlay)
	var shade := ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color = Color(0.025,0.055,0.065,0.72)
	phone_overlay.add_child(shade)
	phone_card = _make_card(phone_overlay, Vector2(650,735), Vector2(395,82))
	var layout := VBoxContainer.new()
	layout.add_theme_constant_override("separation", 12)
	phone_card.add_child(layout)
	var header := HBoxContainer.new()
	var title := _label("הטלפון של השליח", 24, Color("f6f3e9"))
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	header.add_child(_button("סגירה ✕", Callable(self, "_close_phone"), false))
	layout.add_child(header)
	var tabs := GridContainer.new()
	tabs.columns = 4
	for tab in ["משלוחים", "מפה", "הבנק שלי", "פרופיל", "כלי תחבורה", "היסטוריה", "הודעות", "הגדרות"]:
		var tab_btn := _button(tab, Callable(self, "_phone_tab").bind(tab), tab == phone_page)
		tab_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tabs.add_child(tab_btn)
	layout.add_child(tabs)
	var sep := _separator()
	layout.add_child(sep)
	phone_body = VBoxContainer.new()
	phone_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	phone_body.add_theme_constant_override("separation", 10)
	layout.add_child(phone_body)
	phone_overlay.visible = false

func _build_pause_ui() -> void:
	pause_overlay = Control.new()
	pause_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(pause_overlay)
	var shade := ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color = Color(0.02,0.04,0.05,0.78)
	pause_overlay.add_child(shade)
	var panel := _make_card(pause_overlay, Vector2(400,330), Vector2(520,260))
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	panel.add_child(box)
	var heading := _label("המשחק בהשהיה", 28, Color("f6f3e9"))
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(heading)
	box.add_child(_button("המשך במשחק", Callable(self, "_toggle_pause"), true))
	box.add_child(_button("שמירת משחק", Callable(self, "_save_manual"), false))
	box.add_child(_button("חזרה למסך הפתיחה", Callable(self, "_return_to_title"), false))
	pause_overlay.visible = false

func _build_toast() -> void:
	toast_label = Label.new()
	toast_label.anchor_left = 0.27; toast_label.anchor_right = 0.73
	toast_label.anchor_top = 0.08; toast_label.anchor_bottom = 0.15
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	toast_label.add_theme_font_size_override("font_size", 19)
	toast_label.modulate = Color("fff1c9")
	ui_root.add_child(toast_label)
	toast_label.visible = false

func _show_title() -> void:
	title_overlay.visible = true
	hud.visible = false
	phone_overlay.visible = false
	pause_overlay.visible = false

func _start_new_game() -> void:
	player_name = order_name_input.text.strip_edges()
	if player_name.is_empty():
		player_name = "שליח תל אביב"
	company = company_picker.get_item_text(company_picker.selected)
	vehicle = vehicle_picker.get_item_text(vehicle_picker.selected)
	balance = 120
	total_earned = 0
	deliveries_done = 0
	deliveries_declined = 0
	bank_ledger.clear()
	delivery_history.clear()
	app_messages.clear()
	show_minimap = true
	first_person = false
	paid_ids.clear()
	mission_state = 0
	rider.configure(vehicle, company)
	rider.set_carrying_package(false)
	var start_index := _nearest_node(Vector2.ZERO)
	if start_index >= 0:
		var p: Array = graph_nodes[start_index]
		rider.global_position = Vector3(float(p[0]),0.04,float(p[1]))
	_begin_game()
	_new_order()
	_notify("שלום %s, המשמרת שלך מתחילה עכשיו" % player_name)
	_save_game()

func _continue_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		_notify("לא נמצא משחק שמור")
		return
	var text := FileAccess.get_file_as_string(SAVE_PATH)
	var data = JSON.parse_string(text)
	if not data is Dictionary or int(data.get("version",0)) != 1:
		_notify("קובץ השמירה אינו נתמך")
		return
	player_name = str(data.get("player_name","שליח תל אביב"))
	company = str(data.get("company","שליח עצמאי"))
	vehicle = str(data.get("vehicle","אופניים חשמליים"))
	balance = int(data.get("balance",120))
	total_earned = int(data.get("total_earned",0))
	deliveries_done = int(data.get("deliveries_done",0))
	deliveries_declined = int(data.get("deliveries_declined",0))
	bank_ledger.clear()
	for entry in data.get("ledger",[]):
		bank_ledger.append(entry)
	delivery_history.clear()
	for entry in data.get("delivery_history",[]):
		delivery_history.append(entry)
	app_messages.clear()
	for message in data.get("app_messages",[]):
		app_messages.append(str(message))
	show_minimap = bool(data.get("show_minimap",true))
	first_person = bool(data.get("first_person",false))
	paid_ids = data.get("paid_ids",{})
	mission_state = int(data.get("mission_state",0))
	mission_id = int(data.get("mission_id",0))
	mission_restaurant = str(data.get("mission_restaurant",""))
	mission_pay = int(data.get("mission_pay",0))
	mission_dist = float(data.get("mission_dist",0.0))
	pickup_position = _vector_from_array(data.get("pickup",[0,0]))
	dropoff_position = _vector_from_array(data.get("dropoff",[0,0]))
	rider.configure(vehicle,company)
	var pos: Array = data.get("position",[0,0,0])
	rider.global_position = Vector3(float(pos[0]),float(pos[1]),float(pos[2]))
	rider.set_carrying_package(mission_state == 2)
	_begin_game()
	if mission_state == 0:
		_new_order()
	elif mission_state in [1,2]:
		_set_route_for_mission()
	_notify("המשחק השמור נטען בהצלחה")

func _begin_game() -> void:
	game_started = true
	is_paused = false
	is_phone_open = false
	title_overlay.visible = false
	hud.visible = true
	pause_overlay.visible = false
	phone_overlay.visible = false
	rider.controls_enabled = true
	rider.set_first_person(first_person)
	if mini_map:
		mini_map.get_parent().visible = show_minimap
	_update_hud()

func _new_order() -> void:
	if mission_state in [1,2]:
		return
	mission_id += 1
	mission_state = 0
	var candidates: Array = []
	for poi in map_data.get("pois",[]):
		var category := str(poi.get("category",""))
		if category in ["restaurant","cafe","fast_food"]:
			var pos: Array = poi.get("position",[0,0])
			var p := Vector2(float(pos[0]),float(pos[1]))
			if p.length() > 80.0 and p.length() < 850.0:
				candidates.append({"pos":p,"poi":poi})
	if candidates.is_empty():
		var nearest := _nearest_node(Vector2.ZERO)
		if nearest < 0:
			_notify("לא נמצאו מסעדות זמינות באזור")
			return
		var p0: Array = graph_nodes[nearest]
		pickup_position = Vector2(float(p0[0]),float(p0[1]))
		mission_restaurant = "מטבח רוטשילד"
	else:
		candidates.sort_custom(func(a,b): return Vector2(a.pos).length() < Vector2(b.pos).length())
		var chosen: Dictionary = candidates[mini(1,candidates.size()-1)]
		pickup_position = chosen.pos
		var fictional := ["פלאפל בשדרה", "פיצה לב העיר", "קפה שוק הכרמל", "המטבח של דיזנגוף", "שווארמה נחלת בנימין"]
		mission_restaurant = fictional[(mission_id-1) % fictional.size()]
	var pickup_node := _nearest_node(pickup_position)
	var best_node := pickup_node
	var best_score := -1.0
	for i in range(graph_nodes.size()):
		var p: Array = graph_nodes[i]
		var v := Vector2(float(p[0]),float(p[1]))
		var d := v.distance_to(pickup_position)
		if d > 320.0 and d < 780.0 and d > best_score:
			best_score = d
			best_node = i
	if best_node < 0:
		best_node = _nearest_node(pickup_position + Vector2(430,150))
	var target: Array = graph_nodes[maxi(best_node,0)]
	dropoff_position = Vector2(float(target[0]),float(target[1]))
	var planned_route := _find_route(pickup_position,dropoff_position)
	mission_dist = 0.0
	for i in range(1,planned_route.points.size()):
		mission_dist += planned_route.points[i-1].distance_to(planned_route.points[i])
	if mission_dist <= 0.0:
		mission_dist = pickup_position.distance_to(dropoff_position)
	mission_pay = int(28 + mission_dist * 0.075)
	active_route.clear()
	route_active = false
	_update_hud()
	_save_game()

func _accept_order() -> void:
	if mission_state != 0:
		return
	mission_state = 1
	_set_route_for_mission()
	_notify("המשלוח התקבל. נוסעים אל %s" % mission_restaurant)
	_save_game()
	_refresh_phone()

func _reject_order() -> void:
	if mission_state != 0:
		return
	deliveries_declined += 1
	mission_state = 4
	active_route.clear()
	route_active = false
	_notify("ההצעה נדחתה. אפשר לבקש הצעה חדשה בטלפון")
	_refresh_phone()
	_save_game()

func _set_route_for_mission() -> void:
	if mission_state == 1:
		_route_to(pickup_position,"נקודת איסוף")
	elif mission_state == 2:
		_route_to(dropoff_position,"הלקוח")
	_update_hud()

func _interact() -> void:
	if not game_started or is_phone_open or is_paused:
		return
	if mission_state == 1:
		if _rider_position_2d().distance_to(pickup_position) <= 18.0:
			_pickup_order()
		else:
			_notify("צריך להתקרב לנקודת האיסוף כדי לקחת את השקית")
	elif mission_state == 2:
		if _rider_position_2d().distance_to(dropoff_position) <= 18.0:
			_deliver_order()
		else:
			_notify("צריך להתקרב לכתובת הלקוח כדי למסור")
	elif mission_state in [0,3,4]:
		_toggle_phone("משלוחים")

func _pickup_order() -> void:
	mission_state = 2
	rider.set_carrying_package(true)
	_set_route_for_mission()
	_notify("המשלוח נאסף. השקית בתיק — ממשיכים ללקוח")
	_save_game()
	_refresh_phone()

func _deliver_order() -> void:
	var transaction_id := "משלוח-%d" % mission_id
	if paid_ids.has(transaction_id):
		_notify("המשלוח הזה כבר זוכה בחשבון")
		return
	var bonus := 12 if mission_dist < 600.0 else 0
	var payment := mission_pay + bonus
	paid_ids[transaction_id] = true
	balance += payment
	total_earned += payment
	deliveries_done += 1
	bank_ledger.push_front({"id":transaction_id,"description":"תשלום עבור משלוח","amount":payment,"time":Time.get_datetime_string_from_system(false,true)})
	delivery_history.push_front({"id":transaction_id,"restaurant":mission_restaurant,"amount":payment,"distance":int(mission_dist),"time":Time.get_datetime_string_from_system(false,true)})
	if delivery_history.size() > 30:
		delivery_history.pop_back()
	mission_state = 3
	rider.set_carrying_package(false)
	route_active = false
	active_route.clear()
	_notify("המשלוח הושלם — נוספו %d ₪ לחשבון" % payment)
	_save_game()
	_refresh_phone()

func _route_to(target: Vector2, label: String) -> void:
	route_target = target
	navigation_label = label
	var start := _rider_position_2d()
	var route_result := _find_route(start,target)
	active_route = route_result.points
	route_names = route_result.names
	route_active = active_route.size() > 1
	if not route_active:
		active_route = [start,target]
		_notify("אין נתיב מחובר זמין באזור. מוצג קו עזר")
	mini_map.set_navigation(start,active_route,target,route_active)

func _find_route(start: Vector2, target: Vector2) -> Dictionary:
	var from_id := _nearest_node(start)
	var to_id := _nearest_node(target)
	if from_id < 0 or to_id < 0:
		return {"points":[],"names":[]}
	if from_id == to_id:
		var single: Array = graph_nodes[from_id]
		return {"points":[Vector2(single[0],single[1])],"names":[]}
	var count := graph_nodes.size()
	var g := PackedFloat32Array(); g.resize(count)
	var came := PackedInt32Array(); came.resize(count)
	var came_name := PackedStringArray(); came_name.resize(count)
	var closed := PackedByteArray(); closed.resize(count)
	for i in range(count):
		g[i] = INF
		came[i] = -1
	g[from_id] = 0.0
	var heap_nodes: Array[int] = []
	var heap_scores: Array[float] = []
	_heap_push(heap_nodes,heap_scores,from_id,_node_position(from_id).distance_to(_node_position(to_id)))
	var loops := 0
	while not heap_nodes.is_empty() and loops < 18000:
		loops += 1
		var current := _heap_pop(heap_nodes,heap_scores)
		var node_id: int = int(current[0])
		if closed[node_id] == 1:
			continue
		closed[node_id] = 1
		if node_id == to_id:
			break
		for edge in graph_adj[node_id]:
			var next_id := int(edge.to)
			if closed[next_id] == 1:
				continue
			var tentative := g[node_id] + float(edge.distance)
			if tentative < g[next_id]:
				g[next_id] = tentative
				came[next_id] = node_id
				came_name[next_id] = str(edge.name)
				var f := tentative + _node_position(next_id).distance_to(_node_position(to_id))
				_heap_push(heap_nodes,heap_scores,next_id,f)
	if came[to_id] < 0:
		return {"points":[],"names":[]}
	var ids: Array[int] = [to_id]
	var names: Array[String] = []
	var cursor := to_id
	while cursor != from_id and cursor >= 0:
		names.push_front(came_name[cursor])
		cursor = came[cursor]
		if cursor >= 0:
			ids.push_front(cursor)
	var points: Array[Vector2] = [start]
	for id in ids:
		points.append(_node_position(id))
	points.append(target)
	return {"points":points,"names":names}

func _heap_push(nodes: Array[int], scores: Array[float], node: int, score: float) -> void:
	var i := nodes.size()
	nodes.append(node); scores.append(score)
	while i > 0:
		var parent := (i-1)/2
		if scores[parent] <= scores[i]:
			break
		var sn := scores[parent]; scores[parent] = scores[i]; scores[i] = sn
		var nn := nodes[parent]; nodes[parent] = nodes[i]; nodes[i] = nn
		i = parent

func _heap_pop(nodes: Array[int], scores: Array[float]) -> Array:
	var result := [nodes[0],scores[0]]
	var last_node: int = nodes.pop_back()
	var last_score: float = scores.pop_back()
	if not nodes.is_empty():
		nodes[0] = last_node; scores[0] = last_score
		var i := 0
		while true:
			var left := i*2+1; var right := left+1; var smallest := i
			if left < nodes.size() and scores[left] < scores[smallest]:
				smallest = left
			if right < nodes.size() and scores[right] < scores[smallest]:
				smallest = right
			if smallest == i:
				break
			var sn := scores[i]; scores[i] = scores[smallest]; scores[smallest] = sn
			var nn := nodes[i]; nodes[i] = nodes[smallest]; nodes[smallest] = nn
			i = smallest
	return result

func _nearest_node(pos: Vector2) -> int:
	var best_id := -1
	var best := INF
	for i in range(graph_nodes.size()):
		var p: Array = graph_nodes[i]
		var d := Vector2(float(p[0]),float(p[1])).distance_squared_to(pos)
		if d < best:
			best = d
			best_id = i
	return best_id

func _node_position(id: int) -> Vector2:
	var p: Array = graph_nodes[id]
	return Vector2(float(p[0]),float(p[1]))

func _rider_position_2d() -> Vector2:
	return Vector2(rider.global_position.x,rider.global_position.z)

func _update_hud() -> void:
	if not hud_info:
		return
	hud_balance.text = "יתרה: %d ₪" % balance
	var mission_text := "ממתין להצעת משלוח"
	if mission_state == 0:
		mission_text = "יש הצעת משלוח חדשה בטלפון"
	elif mission_state == 1:
		mission_text = "נוסעים לאיסוף: %s" % mission_restaurant
	elif mission_state == 2:
		mission_text = "המשלוח בתיק — נוסעים ללקוח"
	elif mission_state == 3:
		mission_text = "המשלוח הושלם · אפשר לבקש הצעה נוספת בטלפון"
	elif mission_state == 4:
		mission_text = "ההצעה נדחתה · אפשר לבדוק הצעה נוספת בטלפון"
	hud_info.text = "%s  ·  %s קמ״ש" % [vehicle, int(absf(rider.speed_kph))]
	hud_distance.text = mission_text
	if mission_state in [1,2]:
		var dist := _rider_position_2d().distance_to(route_target)
		hud_prompt.text = "E · %s · עוד %d מ׳" % ["איסוף" if mission_state == 1 else "מסירה", int(dist)] if dist <= 32.0 else "יעד: %s · %d מ׳" % [navigation_label,int(dist)]
	elif mission_state == 0:
		hud_prompt.text = "P · פותחים את הטלפון ובוחרים אם לקבל את המשלוח"
	elif mission_state == 3:
		hud_prompt.text = "המשלוח הושלם. P · הזמנה חדשה"
	else:
		hud_prompt.text = "P · בדיקת משלוחים חדשים"

func _update_minimap() -> void:
	if mini_map:
		var target := route_target if route_active else Vector2.ZERO
		mini_map.set_navigation(_rider_position_2d(),active_route,target,route_active)

func _update_target_marker() -> void:
	if not route_active:
		if is_instance_valid(target_marker):
			target_marker.queue_free()
		target_marker = null
		return
	if is_instance_valid(target_marker):
		target_marker.position = Vector3(route_target.x,0,route_target.y)
		return
	target_marker = Node3D.new()
	target_marker.name = "יעד ניווט"
	var pole := MeshInstance3D.new()
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = 0.12; cylinder.bottom_radius = 0.12; cylinder.height = 2.2
	pole.mesh = cylinder; pole.position.y = 1.1
	var material := StandardMaterial3D.new()
	material.albedo_color = Color("edbd40"); material.emission_enabled = true; material.emission = Color("b87515")
	pole.material_override = material
	target_marker.add_child(pole)
	var cap := MeshInstance3D.new()
	var sphere := SphereMesh.new(); sphere.radius = 0.42; sphere.height = 0.84
	cap.mesh = sphere; cap.position.y = 2.35; cap.material_override = material
	target_marker.add_child(cap)
	var label := Label3D.new()
	label.text = navigation_label; label.position.y = 2.9; label.font_size = 36; label.pixel_size = 0.006
	label.modulate = Color("fff1c9"); label.outline_size = 5; label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	target_marker.add_child(label)
	target_marker.position = Vector3(route_target.x,0,route_target.y)
	add_child(target_marker)

func _toggle_phone(page: String) -> void:
	if not game_started:
		return
	if is_paused:
		return
	is_phone_open = not is_phone_open
	if is_phone_open:
		phone_page = page
		phone_overlay.visible = true
		rider.controls_enabled = false
		_refresh_phone()
	else:
		phone_overlay.visible = false
		rider.controls_enabled = true

func _close_phone() -> void:
	is_phone_open = false
	phone_overlay.visible = false
	rider.controls_enabled = true

func _phone_tab(tab: String) -> void:
	phone_page = tab
	_refresh_phone()

func _refresh_phone() -> void:
	if not phone_body:
		return
	for child in phone_body.get_children():
		child.queue_free()
	var heading := _label(phone_page, 24, Color("f4e9c7"))
	phone_body.add_child(heading)
	match phone_page:
		"משלוחים": _phone_orders()
		"מפה": _phone_map()
		"הבנק שלי": _phone_bank()
		"פרופיל": _phone_profile()
		"כלי תחבורה": _phone_vehicle()
		"היסטוריה": _phone_history()
		"הודעות": _phone_messages()
		"הגדרות": _phone_settings()

func _phone_orders() -> void:
	if mission_state == 0:
		phone_body.add_child(_label("הצעת משלוח חדשה",19,Color("f6f3e9")))
		phone_body.add_child(_label("איסוף: %s" % mission_restaurant,16,Color("cbd5d2")))
		phone_body.add_child(_label("כתובת איסוף: %s" % _closest_street_name(pickup_position),14,Color("cbd5d2")))
		phone_body.add_child(_label("כתובת מסירה: %s" % _closest_street_name(dropoff_position),14,Color("cbd5d2")))
		phone_body.add_child(_label("מרחק משוער: %d מ׳" % int(mission_dist),15,Color("cbd5d2")))
		phone_body.add_child(_label("זמן נסיעה משוער: %d דקות" % maxi(5,int(ceil(mission_dist / 260.0)) + 4),14,Color("cbd5d2")))
		phone_body.add_child(_label("תשלום צפוי: %d ₪  ·  בונוס אפשרי: 12 ₪" % mission_pay,16,Color("e9bf55")))
		phone_body.add_child(_label("קבלה או דחייה — ההזמנה לא מתחילה מעצמה.",13,Color("b8c5c5")))
		var row := HBoxContainer.new()
		row.add_child(_button("קבלת משלוח",Callable(self,"_accept_order"),true))
		row.add_child(_button("דחיית משלוח",Callable(self,"_reject_order"),false))
		phone_body.add_child(row)
	elif mission_state in [1,2]:
		phone_body.add_child(_label("סטטוס: %s" % ("בדרך לאיסוף" if mission_state == 1 else "המשלוח נאסף"),18,Color("f6f3e9")))
		phone_body.add_child(_label("מסעדה: %s" % mission_restaurant,15,Color("cbd5d2")))
		phone_body.add_child(_label("מרחק ליעד: %d מ׳" % int(_rider_position_2d().distance_to(route_target)),15,Color("e9bf55")))
		phone_body.add_child(_button("נווט ל%s" % ("מסעדה" if mission_state == 1 else "לקוח"),Callable(self,"_set_route_for_mission"),true))
		phone_body.add_child(_button("ביצוע אינטראקציה  (E)",Callable(self,"_interact"),false))
	else:
		phone_body.add_child(_label("המשלוח האחרון הושלם בהצלחה." if mission_state == 3 else "אין משלוח פעיל כרגע.",17,Color("cbd5d2")))
		phone_body.add_child(_button("בדיקת משלוחים חדשים",Callable(self,"_new_order"),true))
		phone_body.add_child(_label("אחרי קבלת הזמנה יש לנסוע למסעדה, לאסוף את השקית ולמסור ללקוח.",14,Color("b8c5c5")))

func _phone_map() -> void:
	phone_body.add_child(_label("מפה מקומית של מרכז תל אביב",15,Color("cbd5d2")))
	var map := MapPanelScript.new()
	map.custom_minimum_size = Vector2(560,390)
	map.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	map.size_flags_vertical = Control.SIZE_EXPAND_FILL
	map.full_map = true
	map.configure(map_data)
	map.set_navigation(_rider_position_2d(),active_route,route_target,route_active)
	phone_body.add_child(map)
	if mission_state in [1,2]:
		phone_body.add_child(_button("נווט ל%s" % ("מסעדה" if mission_state == 1 else "לקוח"),Callable(self,"_set_route_for_mission"),true))
	phone_body.add_child(_label("מפה: © OpenStreetMap contributors · Open Database License 1.0",10,Color("aebdbd")))

func _phone_bank() -> void:
	phone_body.add_child(_label("יתרה נוכחית",14,Color("b8c5c5")))
	phone_body.add_child(_label("%d ₪" % balance,32,Color("e9bf55")))
	phone_body.add_child(_label("סך הכנסות: %d ₪  ·  משלוחים שהושלמו: %d" % [total_earned,deliveries_done],14,Color("cbd5d2")))
	phone_body.add_child(_separator())
	phone_body.add_child(_label("פעולות אחרונות",16,Color("f6f3e9")))
	if bank_ledger.is_empty():
		phone_body.add_child(_label("עדיין לא נרשמו פעולות בחשבון.",14,Color("aebdbd")))
	else:
		for entry in bank_ledger.slice(0,8):
			phone_body.add_child(_label("%s  ·  +%d ₪" % [str(entry.get("description","תשלום")),int(entry.get("amount",0))],14,Color("d2ddd9")))

func _phone_profile() -> void:
	phone_body.add_child(_label("השליח: %s" % player_name,20,Color("f6f3e9")))
	phone_body.add_child(_label("חברה: %s" % company,15,Color("cbd5d2")))
	phone_body.add_child(_label("דרגה: %s" % ("שליח מתחיל" if deliveries_done < 5 else "שליח פעיל"),16,Color("e9bf55")))
	phone_body.add_child(_label("משלוחים שהושלמו: %d" % deliveries_done,15,Color("cbd5d2")))
	phone_body.add_child(_label("הצעות שנדחו: %d" % deliveries_declined,15,Color("cbd5d2")))
	phone_body.add_child(_label("סך הכסף שהורווח: %d ₪" % total_earned,15,Color("cbd5d2")))

func _phone_vehicle() -> void:
	phone_body.add_child(_label("כלי נוכחי: %s" % vehicle,20,Color("f6f3e9")))
	var speed := 30 if vehicle == "קורקינט חשמלי" else 25
	var accel := "מהירה" if vehicle == "קורקינט חשמלי" else ("רגועה" if vehicle == "קטנוע ישן וחצי שבור" else "בינונית")
	phone_body.add_child(_label("מהירות מרבית במשחק: %d קמ״ש" % speed,15,Color("cbd5d2")))
	phone_body.add_child(_label("תאוצה: %s" % accel,15,Color("cbd5d2")))
	phone_body.add_child(_label("כלי התחבורה משפיע על התאוצה, הפנייה והמהירות בזמן רכיבה.",14,Color("b8c5c5")))
	phone_body.add_child(_label("בחירת הכלי מתבצעת לפני תחילת משמרת.",14,Color("b8c5c5")))

func _phone_history() -> void:
	phone_body.add_child(_label("משלוחים שהושלמו: %d" % deliveries_done,16,Color("cbd5d2")))
	if delivery_history.is_empty():
		phone_body.add_child(_label("לא הושלמו משלוחים עדיין.",15,Color("aebdbd")))
		return
	for item in delivery_history.slice(0,10):
		phone_body.add_child(_label("%s  ·  %d מ׳  ·  +%d ₪" % [str(item.get("restaurant","משלוח")),int(item.get("distance",0)),int(item.get("amount",0))],14,Color("d2ddd9")))

func _phone_messages() -> void:
	phone_body.add_child(_label("הודעות ועדכונים מהמשמרת",15,Color("cbd5d2")))
	if app_messages.is_empty():
		phone_body.add_child(_label("אין הודעות חדשות.",15,Color("aebdbd")))
	else:
		for message in app_messages.slice(0,8):
			phone_body.add_child(_label("•  %s" % message,14,Color("d2ddd9")))
	var refresh := _button("בקשת הצעת משלוח",Callable(self,"_new_order"),true)
	refresh.disabled = mission_state in [1,2,0]
	phone_body.add_child(refresh)

func _phone_settings() -> void:
	phone_body.add_child(_label("העדפות תצוגה",16,Color("cbd5d2")))
	var map_toggle := CheckButton.new()
	map_toggle.text = "הצגת מפה קטנה במסך המשחק"
	map_toggle.button_pressed = show_minimap
	map_toggle.toggled.connect(_set_minimap_enabled)
	phone_body.add_child(map_toggle)
	var camera_toggle := CheckButton.new()
	camera_toggle.text = "מבט מגוף ראשון"
	camera_toggle.button_pressed = first_person
	camera_toggle.toggled.connect(_set_first_person)
	phone_body.add_child(camera_toggle)
	phone_body.add_child(_label("הגדרות אלה נשמרות עם המשחק. שאר הגדרות הגרפיקה אינן זמינות בגרסה זו.",14,Color("b8c5c5")))

func _set_minimap_enabled(enabled: bool) -> void:
	show_minimap = enabled
	if mini_map:
		mini_map.get_parent().visible = enabled
	_save_game()

func _set_first_person(enabled: bool) -> void:
	first_person = enabled
	if rider:
		rider.set_first_person(enabled)
	_save_game()

func _closest_street_name(position: Vector2) -> String:
	var closest := INF
	var street := "נקודת מפגש"
	for road in map_data.get("roads",[]):
		for point in road.get("points",[]):
			var p := Vector2(float(point[0]),float(point[1]))
			var distance := p.distance_squared_to(position)
			if distance < closest:
				closest = distance
				street = str(road.get("name",street))
	return street

func _toggle_pause() -> void:
	if not game_started:
		return
	is_paused = not is_paused
	pause_overlay.visible = is_paused
	rider.controls_enabled = not is_paused and not is_phone_open
	get_tree().paused = is_paused
	pause_overlay.process_mode = Node.PROCESS_MODE_ALWAYS

func _return_to_title() -> void:
	if is_paused:
		get_tree().paused = false
	is_paused = false
	game_started = false
	rider.controls_enabled = false
	_save_game()
	_show_title()

func _notify(message: String) -> void:
	app_messages.push_front(message)
	if app_messages.size() > 20:
		app_messages.pop_back()
	if toast_label:
		toast_label.text = message
		toast_label.visible = true
		toast_timer = 3.2

func _save_manual() -> void:
	_save_game(true)

func _save_game(show_toast: bool = false) -> void:
	if not rider:
		return
	var data := {
		"version":1,"player_name":player_name,"company":company,"vehicle":vehicle,
			"balance":balance,"total_earned":total_earned,"deliveries_done":deliveries_done,
			"deliveries_declined":deliveries_declined,"ledger":bank_ledger,"delivery_history":delivery_history,
			"app_messages":app_messages,"show_minimap":show_minimap,"first_person":first_person,"paid_ids":paid_ids,
		"mission_state":mission_state,"mission_id":mission_id,"mission_restaurant":mission_restaurant,
		"mission_pay":mission_pay,"mission_dist":mission_dist,
		"pickup":[pickup_position.x,pickup_position.y],"dropoff":[dropoff_position.x,dropoff_position.y],
		"position":[rider.global_position.x,rider.global_position.y,rider.global_position.z]
	}
	var file := FileAccess.open(SAVE_PATH,FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data,"\t"))
		file.close()
		if show_toast and toast_label and game_started:
			_notify("המשחק נשמר")

func _vector_from_array(value: Array) -> Vector2:
	return Vector2(float(value[0]),float(value[1])) if value.size() >= 2 else Vector2.ZERO

func _make_card(parent: Control, size: Vector2, pos: Vector2) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.position = pos
	panel.size = size
	panel.custom_minimum_size = size
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.075,0.12,0.14,0.96)
	style.border_color = Color("334a4d")
	style.set_border_width_all(1)
	style.set_corner_radius_all(14)
	style.content_margin_left = 18; style.content_margin_right = 18
	style.content_margin_top = 16; style.content_margin_bottom = 16
	panel.add_theme_stylebox_override("panel",style)
	parent.add_child(panel)
	return panel

func _label(text: String, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size",size)
	label.modulate = color
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	label.layout_direction = Control.LAYOUT_DIRECTION_RTL
	return label

func _button(text: String, action: Callable, primary: bool) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size = Vector2(0,42)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.add_theme_font_size_override("font_size",15)
	button.layout_direction = Control.LAYOUT_DIRECTION_RTL
	var style := StyleBoxFlat.new()
	style.bg_color = Color("d8ad3e") if primary else Color("1b3035")
	style.border_color = Color("eac45c") if primary else Color("40575b")
	style.set_border_width_all(1)
	style.set_corner_radius_all(9)
	style.content_margin_left = 12; style.content_margin_right = 12
	style.content_margin_top = 8; style.content_margin_bottom = 8
	button.add_theme_stylebox_override("normal",style)
	var hover := style.duplicate()
	hover.bg_color = Color("efc955") if primary else Color("284249")
	button.add_theme_stylebox_override("hover",hover)
	button.add_theme_color_override("font_color",Color("172329") if primary else Color("edf1ea"))
	button.pressed.connect(action)
	return button

func _separator() -> HSeparator:
	var line := HSeparator.new()
	line.add_theme_constant_override("separation",4)
	return line
