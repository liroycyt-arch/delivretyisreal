extends RefCounted
class_name TelAvivMapBuilder

const ROAD_Y := 0.045

static func build(parent: Node3D, data: Dictionary) -> Dictionary:
	_add_lighting(parent)
	_add_ground(parent)
	var road_mesh := _make_roads(data.get("roads", []))
	var road_instance := MeshInstance3D.new()
	road_instance.name = "כבישים מרחובות תל אביב"
	road_instance.mesh = road_mesh
	var road_material := StandardMaterial3D.new()
	road_material.vertex_color_use_as_albedo = true
	road_material.roughness = 0.92
	road_instance.material_override = road_material
	parent.add_child(road_instance)
	var building_mesh := _make_buildings(data.get("buildings", []))
	var building_instance := MeshInstance3D.new()
	building_instance.name = "מבנים"
	building_instance.mesh = building_mesh.mesh
	building_instance.material_override = building_mesh.material
	parent.add_child(building_instance)
	var block_body := StaticBody3D.new()
	block_body.name = "קירות המבנים"
	var collision := CollisionShape3D.new()
	var shape := ConcavePolygonShape3D.new()
	shape.backface_collision = true
	shape.set_faces(building_mesh.mesh.get_faces())
	collision.shape = shape
	block_body.add_child(collision)
	parent.add_child(block_body)
	_add_poi_markers(parent, data.get("pois", []))
	return {"roads": data.get("roads", []), "buildings": data.get("buildings", []), "pois": data.get("pois", [])}

static func _add_lighting(parent: Node3D) -> void:
	var world := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = Sky.new()
	env.sky.sky_material = ProceduralSkyMaterial.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.72, 0.79, 0.86)
	env.ambient_light_energy = 0.65
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world.environment = env
	parent.add_child(world)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_color = Color(1.0, 0.88, 0.68)
	sun.light_energy = 1.05
	sun.shadow_enabled = true
	parent.add_child(sun)

static func _add_ground(parent: Node3D) -> void:
	var ground := MeshInstance3D.new()
	ground.name = "קרקע עירונית"
	var plane := PlaneMesh.new()
	plane.size = Vector2(3000, 3000)
	ground.mesh = plane
	ground.position.y = -0.12
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color("b4ad9d")
	mat.roughness = 1.0
	ground.material_override = mat
	parent.add_child(ground)
	var collider := StaticBody3D.new()
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(3000, 0.2, 3000)
	shape.shape = box
	collider.position.y = -0.22
	collider.add_child(shape)
	parent.add_child(collider)

static func _make_roads(roads: Array) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for road in roads:
		var kind: String = str(road.get("kind", "residential"))
		var width := float(road.get("width", 5.0))
		var color := _road_color(kind)
		var points: Array = road.get("points", [])
		for i in range(points.size() - 1):
			var a: Vector2 = Vector2(points[i][0], points[i][1])
			var b: Vector2 = Vector2(points[i + 1][0], points[i + 1][1])
			var delta := b - a
			if delta.length_squared() < 0.01:
				continue
			var side := Vector2(-delta.y, delta.x).normalized() * width * 0.5
			var a1 := Vector3(a.x + side.x, ROAD_Y, a.y + side.y)
			var a2 := Vector3(a.x - side.x, ROAD_Y, a.y - side.y)
			var b1 := Vector3(b.x + side.x, ROAD_Y, b.y + side.y)
			var b2 := Vector3(b.x - side.x, ROAD_Y, b.y - side.y)
			_push_quad(st, a1, b1, b2, a2, color)
	var mesh := st.commit()
	if mesh == null:
		return ArrayMesh.new()
	return mesh

static func _make_buildings(buildings: Array) -> Dictionary:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261023
	for building in buildings:
		var center: Array = building.get("center", [0.0, 0.0])
		var size: Array = building.get("size", [8.0, 8.0])
		var x := float(center[0])
		var z := float(center[1])
		var sx := maxf(2.2, float(size[0]))
		var sz := maxf(2.2, float(size[1]))
		var height := float(building.get("height", 10.0))
		var tint := rng.randf_range(-0.035, 0.035)
		var color := Color(0.79 + tint, 0.73 + tint, 0.63 + tint)
		var x0 := x - sx * 0.47
		var x1 := x + sx * 0.47
		var z0 := z - sz * 0.47
		var z1 := z + sz * 0.47
		var y0 := 0.0
		var y1 := maxf(4.0, height)
		var v000 := Vector3(x0,y0,z0); var v100 := Vector3(x1,y0,z0)
		var v010 := Vector3(x0,y1,z0); var v110 := Vector3(x1,y1,z0)
		var v001 := Vector3(x0,y0,z1); var v101 := Vector3(x1,y0,z1)
		var v011 := Vector3(x0,y1,z1); var v111 := Vector3(x1,y1,z1)
		_add_face(st, v000, v010, v110, v100, Vector3(0,0,-1), color)
		_add_face(st, v101, v111, v011, v001, Vector3(0,0,1), color.darkened(0.04))
		_add_face(st, v001, v011, v010, v000, Vector3(-1,0,0), color.darkened(0.07))
		_add_face(st, v100, v110, v111, v101, Vector3(1,0,0), color.lightened(0.025))
		_add_face(st, v010, v011, v111, v110, Vector3(0,1,0), Color(0.84,0.79,0.69))
	var mesh := st.commit()
	var material := StandardMaterial3D.new()
	material.vertex_color_use_as_albedo = true
	material.roughness = 0.9
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	return {"mesh": mesh, "material": material}

static func _add_face(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3, normal: Vector3, color: Color) -> void:
	for vertex in [a,b,c,a,c,d]:
		st.set_normal(normal)
		st.set_color(color)
		st.add_vertex(vertex)

static func _push_quad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3, color: Color) -> void:
	for vertex in [a,b,c,a,c,d]:
		st.set_color(color)
		st.add_vertex(vertex)

static func _road_color(kind: String) -> Color:
	match kind:
		"primary", "trunk", "secondary": return Color("484c4c")
		"tertiary", "unclassified": return Color("575957")
		"pedestrian", "footway", "path": return Color("a8a192")
		"cycleway": return Color("667c71")
		_: return Color("626463")

static func _add_poi_markers(parent: Node3D, pois: Array) -> void:
	var root := Node3D.new()
	root.name = "עסקים בעיר"
	parent.add_child(root)
	var count := mini(pois.size(), 120)
	var step := maxi(1, int(pois.size() / maxf(1.0, float(count))))
	for i in range(0, pois.size(), step):
		if root.get_child_count() >= count:
			break
		var poi: Dictionary = pois[i]
		var pos: Array = poi.get("position", [0.0,0.0])
		var marker := MeshInstance3D.new()
		var cylinder := CylinderMesh.new()
		cylinder.top_radius = 0.22
		cylinder.bottom_radius = 0.28
		cylinder.height = 0.55
		marker.mesh = cylinder
		marker.position = Vector3(float(pos[0]), 0.28, float(pos[1]))
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color("e6a736") if str(poi.get("category", "")) in ["restaurant", "cafe", "fast_food"] else Color("5e9a91")
		mat.roughness = 0.75
		marker.material_override = mat
		root.add_child(marker)
