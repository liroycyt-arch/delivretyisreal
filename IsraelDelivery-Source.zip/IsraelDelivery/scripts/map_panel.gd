extends Control
class_name DeliveryMapPanel

var roads: Array = []
var route_points: Array[Vector2] = []
var player_position := Vector2.ZERO
var target_position := Vector2.ZERO
var show_target := false
var full_map := false
var _bounds := Rect2(-1000, -1000, 2000, 2000)

func configure(map_data: Dictionary) -> void:
	roads = map_data.get("roads", [])
	var found := false
	var min_x := INF; var max_x := -INF; var min_y := INF; var max_y := -INF
	for road in roads:
		for point in road.get("points", []):
			var p := Vector2(float(point[0]), float(point[1]))
			min_x = minf(min_x, p.x); max_x = maxf(max_x, p.x)
			min_y = minf(min_y, p.y); max_y = maxf(max_y, p.y)
			found = true
	if found:
		_bounds = Rect2(min_x, min_y, max_x - min_x, max_y - min_y).grow(35.0)
	queue_redraw()

func set_navigation(player: Vector2, route: Array, target: Vector2, active: bool) -> void:
	player_position = player
	route_points.clear()
	for p in route:
		route_points.append(Vector2(p))
	target_position = target
	show_target = active
	queue_redraw()

func _draw() -> void:
	var size := get_rect().size
	if size.x <= 0 or size.y <= 0:
		return
	draw_rect(Rect2(Vector2.ZERO, size), Color("102128"), true)
	var center := size * 0.5
	var scale_factor := minf(size.x / maxf(_bounds.size.x,1.0), size.y / maxf(_bounds.size.y,1.0)) * 0.97
	var world_center := _bounds.get_center()
	if not full_map:
		scale_factor = minf(size.x / 440.0, size.y / 330.0)
		world_center = player_position
	for road in roads:
		var pts: Array = road.get("points", [])
		if pts.size() < 2:
			continue
		var color := Color("778184") if str(road.get("kind", "")) in ["primary","secondary","trunk"] else Color("46575b")
		for i in range(pts.size()-1):
			var a := _project(Vector2(float(pts[i][0]), float(pts[i][1])), center, world_center, scale_factor)
			var b := _project(Vector2(float(pts[i+1][0]), float(pts[i+1][1])), center, world_center, scale_factor)
			draw_line(a, b, color, 1.1 if full_map else 0.65, true)
	if route_points.size() > 1:
		for i in range(route_points.size()-1):
			draw_line(_project(route_points[i],center,world_center,scale_factor), _project(route_points[i+1],center,world_center,scale_factor), Color("f3c34b"), 4.0 if full_map else 2.3, true)
	if show_target:
		var t := _project(target_position,center,world_center,scale_factor)
		draw_circle(t, 6.5 if full_map else 4.5, Color("f26f54"))
		draw_arc(t, 9.0 if full_map else 6.0, 0, TAU, 32, Color.WHITE, 1.4, true)
	var p := _project(player_position,center,world_center,scale_factor)
	draw_circle(p, 6.2 if full_map else 4.0, Color("74d8d0"))
	draw_arc(p, 9.0 if full_map else 6.0, 0, TAU, 32, Color.WHITE, 1.5, true)
	draw_rect(Rect2(Vector2.ZERO,size), Color("9eb2b5"), false, 1.5)

func _project(world: Vector2, center: Vector2, world_center: Vector2, scale_factor: float) -> Vector2:
	return center + Vector2(world.x - world_center.x, world.y - world_center.y) * scale_factor
