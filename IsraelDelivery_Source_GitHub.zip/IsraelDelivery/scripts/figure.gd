class_name Figure
extends Node3D
## דמות אנושית מדורגת (פרימיטיבים + שלד היררכי + IK דו-עצמות לרגליים ולידיים).
## זה לא מודל משוכלל; ניתן להחליף ב-Skeleton3D/GLB בעתיד תוך שמירה על ה-API (build / ride_pose / pose_stand).

const SKINS := [Color("f1c9a5"), Color("e0ac7e"), Color("c68642"), Color("8d5524"), Color("5c3a21")]
const HAIRS := [Color("1b1b1b"), Color("4a2c17"), Color("a0522d"), Color("c9a26b"), Color("7a7a7a")]
const HELMETS := [Color("e8e8e8"), Color("202020"), Color("d62828"), Color("1d6fd1"), Color("f2c200")]
const CASUAL := [Color("c0392b"), Color("27ae60"), Color("8e44ad"), Color("e67e22"), Color("7f8c8d"), Color("2c3e50")]
const L1 := 0.45
const L2 := 0.45
const A1 := 0.30
const A2 := 0.33
const POSES := {
    "ebike": {"hip": Vector3(0, 0.95, 0.12), "bar": Vector3(0.2, 1.09, -0.26), "pedal": true},
    "scooter": {"hip": Vector3(0, 1.05, 0.2), "bar": Vector3(0.18, 1.30, -0.28), "pedal": false, "foot_z": 0.25, "foot_y": 0.2},
    "moped": {"hip": Vector3(0, 0.80, 0.15), "bar": Vector3(0.2, 1.05, -0.30), "pedal": false, "foot_z": -0.25, "foot_y": 0.22},
}

var pelvis: Node3D
var torso: Node3D
var head: Node3D
var helmet_node: Node3D
var hair_node: Node3D
var carry_mark: Node3D
var hips := {}
var knees := {}
var shoulders := {}
var elbows := {}


static func _mat(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = 0.85
    return m


func _add(parent: Node3D, mesh: Mesh, c: Color, pos := Vector3.ZERO) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    mi.material_override = _mat(c)
    mi.position = pos
    parent.add_child(mi)
    return mi


func _bx(x: float, y: float, z: float) -> BoxMesh:
    var b := BoxMesh.new()
    b.size = Vector3(x, y, z)
    return b


func _sp(r: float) -> SphereMesh:
    var s := SphereMesh.new()
    s.radius = r
    s.height = r * 2.0
    return s


func build(look: Dictionary, company: String) -> void:
    for c in get_children():
        c.queue_free()
    hips.clear()
    knees.clear()
    shoulders.clear()
    elbows.clear()
    var casual: bool = look.has("shirt")
    var skin: Color = SKINS[clampi(int(look.get("skin", 0)), 0, SKINS.size() - 1)]
    var hair: Color = HAIRS[clampi(int(look.get("hair_color", 0)), 0, HAIRS.size() - 1)]
    var hcol: Color = HELMETS[clampi(int(look.get("helmet", 0)), 0, HELMETS.size() - 1)]
    var bs: float = [0.92, 1.0, 1.12][clampi(int(look.get("body", 1)), 0, 2)]
    var style := int(look.get("hair_style", 0))
    var shorts := bool(look.get("shorts", false))
    var shirt := Color("ffd600")
    var txt := Color.BLACK
    var label := "משלוחה"
    if company == "wolt":
        shirt = Color("009de0")
        txt = Color.WHITE
        label = "וולט"
    elif company == "indie":
        shirt = Color("202020")
        txt = Color("ffd600")
        label = "שליח"
    if casual:
        shirt = CASUAL[int(look.shirt) % CASUAL.size()]
    var pants := Color("2a2e36")
    var shoes := Color("151515")
    var top := L1 + L2 + 0.07

    pelvis = Node3D.new()
    pelvis.position = Vector3(0, top, 0)
    add_child(pelvis)
    _add(pelvis, _bx(0.34 * bs, 0.2, 0.22), pants, Vector3(0, 0.02, 0))
    torso = Node3D.new()
    torso.position = Vector3(0, 0.1, 0)
    pelvis.add_child(torso)
    _add(torso, _bx(0.42 * bs, 0.56, 0.24), shirt, Vector3(0, 0.27, 0))

    if not casual:
        for side in [1.0, -1.0]:
            var lb := Label3D.new()
            lb.text = label
            lb.font = Game.font
            lb.font_size = 72
            lb.pixel_size = 0.0022
            lb.modulate = txt
            lb.position = Vector3(0, 0.2 if side > 0 else 0.4, 0.126 * side)
            if side < 0:
                lb.rotation.y = PI
                lb.font_size = 40
            torso.add_child(lb)
        if company == "mishloha":
            _add(torso, _bx(0.12, 0.14, 0.02), Color("111111"), Vector3(0, 0.42, 0.13))
            var ring := TorusMesh.new()
            ring.inner_radius = 0.025
            ring.outer_radius = 0.04
            var rm := _add(torso, ring, Color("111111"), Vector3(0, 0.51, 0.13))
            rm.rotation.x = PI / 2.0
        var bp := Color("ffd600") if company == "mishloha" else (Color("009de0") if company == "wolt" else Color("303030"))
        _add(torso, _bx(0.40, 0.42, 0.22), bp, Vector3(0, 0.3, 0.24))
        carry_mark = Node3D.new()
        carry_mark.visible = false
        torso.add_child(carry_mark)
        _add(carry_mark, _bx(0.26, 0.2, 0.12), Color("111111"), Vector3(0, 0.62, 0.24))

    head = Node3D.new()
    head.position = Vector3(0, 0.68, 0)
    torso.add_child(head)
    var neck := CylinderMesh.new()
    neck.top_radius = 0.05
    neck.bottom_radius = 0.055
    neck.height = 0.1
    _add(torso, neck, skin, Vector3(0, 0.6, 0))
    var hd := _add(head, _sp(0.12), skin)
    hd.scale = Vector3(1, 1.15, 1)
    _add(head, _sp(0.012), Color.BLACK, Vector3(-0.045, 0.02, -0.108))
    _add(head, _sp(0.012), Color.BLACK, Vector3(0.045, 0.02, -0.108))
    hair_node = Node3D.new()
    head.add_child(hair_node)
    if style != 3:
        var hm := _add(hair_node, _sp(0.126 if style == 0 else 0.121), hair, Vector3(0, 0.07 if style == 0 else 0.09, 0.012))
        hm.scale = Vector3(1, 0.55 if style == 0 else 0.4, 1)
    if style == 2:
        _add(hair_node, _bx(0.22, 0.24, 0.06), hair, Vector3(0, -0.03, 0.1))
    helmet_node = Node3D.new()
    head.add_child(helmet_node)
    var hl := _add(helmet_node, _sp(0.155), hcol, Vector3(0, 0.05, 0.012))
    hl.scale = Vector3(1, 0.8, 1.08)
    helmet_node.visible = bool(look.get("helmet_on", not casual))

    for s in ["L", "R"]:
        var sx := -1.0 if s == "L" else 1.0
        var sh := Node3D.new()
        sh.position = Vector3(sx * 0.24 * bs, 0.47, 0)
        torso.add_child(sh)
        shoulders[s] = sh
        _add(sh, _bx(0.1, A1, 0.1), shirt, Vector3(0, -A1 / 2.0, 0))
        var el := Node3D.new()
        el.position = Vector3(0, -A1, 0)
        sh.add_child(el)
        elbows[s] = el
        _add(el, _bx(0.085, A2 - 0.05, 0.085), skin, Vector3(0, -(A2 - 0.05) / 2.0, 0))
        _add(el, _sp(0.05), skin, Vector3(0, -(A2 - 0.03), 0))
        var hp := Node3D.new()
        hp.position = Vector3(sx * 0.1 * bs, 0, 0)
        pelvis.add_child(hp)
        hips[s] = hp
        _add(hp, _bx(0.15, L1, 0.16), skin if shorts else pants, Vector3(0, -L1 / 2.0, 0))
        var kn := Node3D.new()
        kn.position = Vector3(0, -L1, 0)
        hp.add_child(kn)
        knees[s] = kn
        _add(kn, _bx(0.12, L2, 0.13), skin if shorts else pants, Vector3(0, -L2 / 2.0, 0))
        _add(kn, _bx(0.11, 0.07, 0.27), shoes, Vector3(0, -L2 - 0.03, -0.06))
    pose_stand(0.0, 0.0)


static func _ik(l1: float, l2: float, tf: float, ty: float, s: float) -> Vector2:
    var d := clampf(Vector2(tf, ty).length(), 0.05, l1 + l2 - 0.001)
    var tht := atan2(tf, -ty)
    var a := acos(clampf((l1 * l1 + d * d - l2 * l2) / (2.0 * l1 * d), -1.0, 1.0))
    var g := acos(clampf((l1 * l1 + l2 * l2 - d * d) / (2.0 * l1 * l2), -1.0, 1.0))
    return Vector2(tht + s * a, -s * (PI - g))


func leg_to(side: String, tf: float, ty: float) -> void:
    var r := _ik(L1, L2, tf, ty, 1.0)
    hips[side].rotation.x = r.x
    knees[side].rotation.x = r.y


func arm_to(side: String, tf: float, ty: float) -> void:
    var r := _ik(A1, A2, tf, ty, -1.0)
    shoulders[side].rotation.x = r.x
    elbows[side].rotation.x = r.y


func pose_stand(walk: float, t: float) -> void:
    pelvis.position = Vector3(0, L1 + L2 + 0.07, 0)
    torso.rotation.x = 0.0
    var sw := sin(t) * 0.55 * walk
    hips["L"].rotation.x = sw
    hips["R"].rotation.x = -sw
    knees["L"].rotation.x = -maxf(0.0, -sw) * 0.9
    knees["R"].rotation.x = -maxf(0.0, sw) * 0.9
    shoulders["L"].rotation.x = -sw * 0.8
    shoulders["R"].rotation.x = sw * 0.8
    elbows["L"].rotation.x = 0.2
    elbows["R"].rotation.x = 0.2


func ride_pose(kind: String, phase: float) -> void:
    var p: Dictionary = POSES[kind]
    var hip: Vector3 = p["hip"]
    var bar: Vector3 = p["bar"]
    pelvis.position = hip
    torso.rotation.x = 0.0
    var sy := hip.y + 0.57
    for s in ["L", "R"]:
        var ph := phase + (0.0 if s == "L" else PI)
        var fz := 0.0
        var fy := 0.0
        if p["pedal"]:
            fz = -0.05 + 0.12 * sin(ph)
            fy = 0.30 + 0.12 * cos(ph)
        else:
            fz = float(p["foot_z"])
            fy = float(p["foot_y"])
        leg_to(s, hip.z - fz, fy - hip.y)
        arm_to(s, hip.z - bar.z, bar.y - sy)


func pose_receive() -> void:
    arm_to("R", 0.5, -0.1)
    arm_to("L", 0.5, -0.1)
