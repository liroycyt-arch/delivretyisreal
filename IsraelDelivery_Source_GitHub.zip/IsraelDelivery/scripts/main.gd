extends Node
## התזמור: עולם, שחקן, סביבה, זרימת משימות, שמירה, השהיה והגדרות.

var world: World
var player: Player
var ui: UI
var sun: DirectionalLight3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var marker: MeshInstance3D
var marker_mat: StandardMaterial3D
var customer: Figure = null
var sfx_player: AudioStreamPlayer
var sounds := {}
var in_game := false
var is_paused := false
var _offer_t := 8.0
var _save_t := 0.0
var _pos_t := 0.0
var _last_state := ""


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    get_window().title = "משלוחים בישראל"
    world = World.new()
    world.process_mode = Node.PROCESS_MODE_PAUSABLE
    add_child(world)
    Game.world = world
    _make_environment()
    marker = MeshInstance3D.new()
    var cy := CylinderMesh.new()
    cy.top_radius = 1.4
    cy.bottom_radius = 1.4
    cy.height = 50.0
    marker.mesh = cy
    var mm := StandardMaterial3D.new()
    mm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mm.albedo_color = Color(1, 0.84, 0, 0.3)
    marker.material_override = mm
    marker_mat = mm
    marker.visible = false
    add_child(marker)
    sfx_player = AudioStreamPlayer.new()
    add_child(sfx_player)
    sounds = {
        "offer": _tone([880, 1175]), "pickup": _tone([660, 880]), "done": _tone([660, 880, 1320]),
        "error": _tone([220]),
    }
    ui = UI.new()
    ui.main = self
    add_child(ui)
    Game.notify.connect(_on_notify)
    Game.sfx.connect(_play)
    Game.mission_changed.connect(_on_mission_changed)
    Game.appearance_changed.connect(_on_appearance)
    apply_settings()
    ui.show_main_menu()


func _tone(freqs: Array, dur := 0.13) -> AudioStreamWAV:
    var rate := 22050
    var n := int(rate * dur)
    var data := PackedByteArray()
    data.resize(n * 2 * freqs.size())
    var idx := 0
    for f in freqs:
        for k in range(n):
            var e := 1.0 - float(k) / n
            data.encode_s16(idx, int(sin(TAU * f * k / rate) * e * 0.4 * 32767.0))
            idx += 2
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = rate
    w.stereo = false
    w.data = data
    return w


func _play(n: String) -> void:
    if bool(Game.settings.get("mute_notify", false)) or not sounds.has(n):
        return
    sfx_player.stream = sounds[n]
    sfx_player.volume_db = linear_to_db(maxf(0.001, float(Game.settings.get("volume", 0.8))))
    sfx_player.play()


func _on_notify(t: String) -> void:
    if bool(Game.settings.get("voice", false)):
        var voices := DisplayServer.tts_get_voices_for_language("he")
        if voices.size() > 0:
            DisplayServer.tts_speak(t, voices[0])


func _make_environment() -> void:
    sun = DirectionalLight3D.new()
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 140.0
    add_child(sun)
    sky_mat = ProceduralSkyMaterial.new()
    var sky := Sky.new()
    sky.sky_material = sky_mat
    env = Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_density = 0.0012
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)


func apply_settings() -> void:
    var s: Dictionary = Game.settings
    var hour := float(s.time)
    var t := clampf((hour - 6.0) / 12.0, 0.0, 1.0)
    var elev := sin(t * PI) * 70.0 + 6.0
    sun.rotation_degrees = Vector3(-elev, lerpf(-70.0, 70.0, t), 0.0)
    sun.light_energy = clampf(sin(t * PI) * 1.3 + 0.15, 0.15, 1.3)
    sun.light_color = Color("ffd9a8").lerp(Color.WHITE, clampf(elev / 60.0, 0.0, 1.0))
    sky_mat.sky_top_color = Color("1e4a85").lerp(Color("101a38"), 1.0 - clampf(elev / 50.0, 0.0, 1.0))
    sky_mat.sky_horizon_color = Color("a9c6e0").lerp(Color("e8956a"), 1.0 - clampf(elev / 40.0, 0.0, 1.0))
    env.ambient_light_energy = clampf(elev / 50.0, 0.35, 1.0)
    sun.shadow_enabled = bool(s.shadows)
    world.set_quality(int(s.quality))
    Engine.max_fps = int(s.fps)
    var win := get_window()
    win.mode = Window.MODE_FULLSCREEN if bool(s.fullscreen) else Window.MODE_WINDOWED
    get_viewport().msaa_3d = [Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X][clampi(int(s.quality), 0, 2)]
    if player:
        player.light.visible = hour >= 18.0
        player.light.shadow_enabled = false


# ---------- זרימה ----------
func new_game() -> void:
    Game.reset_new()
    ui.show_setup()


func continue_game() -> void:
    Game.load_game()
    begin_play(false)


func begin_play(is_new: bool) -> void:
    ui.show_loading()
    Game.world = world
    var pos: Vector3 = Vector3(8 * World.S, 0.3, 12 * World.S) if is_new else Game.last_pos
    if is_new:
        Game.last_pos = pos
        Game.last_heading = 0.0
        Game.mission = {}
        Game.stop_nav()
    await world.preload_around(pos, ui.set_progress)
    if player != null:
        player.queue_free()
    player = Player.new()
    add_child(player)
    player.global_position = pos
    player.heading = Game.last_heading
    player.rotation.y = player.heading
    player.setup(Game.look, Game.company, Game.vehicle)
    Game.player = player
    in_game = true
    is_paused = false
    get_tree().paused = false
    ui.clear_screen()
    ui.show_hud(player, world)
    _offer_t = 6.0
    _last_state = ""
    _on_mission_changed()
    apply_settings()
    _update_mouse()
    if is_new:
        Game.notify.emit("ברוך הבא, %s! הזמנה ראשונה תגיע בקרוב. P פותח את הטלפון" % Game.player_name)
        Game.save_game()


func _on_appearance() -> void:
    if player != null and in_game:
        player.setup(Game.look, Game.company, Game.vehicle)
        player.set_carrying(Game.mission.get("state", "") == "to_customer")


func _on_mission_changed() -> void:
    if player == null:
        return
    var m: Dictionary = Game.mission
    var st: String = m.get("state", "")
    marker.visible = false
    if st == "to_pickup" or st == "to_customer":
        var p: Dictionary = world.poi(m.ri, m.rj) if st == "to_pickup" else world.poi(m.hi, m.hj)
        marker.global_position = Vector3(p.door.x, 25.0, p.door.z)
        marker_mat.albedo_color = Color(1, 0.84, 0, 0.3) if st == "to_pickup" else Color(0.18, 0.8, 0.44, 0.3)
        marker.visible = true
    if st != _last_state:
        if st == "to_customer" and not bool(m.get("leave", false)):
            _spawn_customer(world.poi(m.hi, m.hj))
        elif st != "to_customer":
            _free_customer()
        _last_state = st
    player.set_carrying(st == "to_customer" and not player.bag.visible)
    if m.is_empty():
        Game.stop_nav()


func _spawn_customer(p: Dictionary) -> void:
    _free_customer()
    customer = Figure.new()
    add_child(customer)
    var lk := {"skin": p.h % 5, "hair_color": (p.h / 5) % 5, "hair_style": (p.h / 25) % 4, "body": (p.h / 7) % 3, "shirt": (p.h / 11) % 6, "shorts": (p.h % 2) == 0}
    customer.build(lk, "customer")
    customer.global_position = p.door + Vector3(1.4, 0, -0.9)
    customer.rotation.y = PI


func _free_customer() -> void:
    if customer != null and is_instance_valid(customer):
        customer.queue_free()
    customer = null


func set_phone(open: bool, page := "home") -> void:
    if not in_game:
        return
    if open:
        ui.open_phone(page)
    else:
        ui.close_phone()
    player.input_enabled = not open
    _update_mouse()


func _update_mouse() -> void:
    if in_game and not ui.phone_open and not is_paused:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    else:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func pause_game() -> void:
    if not in_game or is_paused:
        return
    _save_progress()
    is_paused = true
    get_tree().paused = true
    ui.show_pause()
    _update_mouse()


func resume() -> void:
    is_paused = false
    get_tree().paused = false
    ui.clear_screen()
    _update_mouse()


func _save_progress() -> void:
    if player != null:
        Game.last_pos = Vector3(player.global_position.x, maxf(0.3, player.global_position.y), player.global_position.z)
        Game.last_heading = player.heading
    Game.save_game()


func save_and_menu() -> void:
    _save_progress()
    get_tree().paused = false
    in_game = false
    is_paused = false
    if player != null:
        player.queue_free()
        player = null
        Game.player = null
    _free_customer()
    marker.visible = false
    ui.close_phone()
    Game.load_game()
    ui.show_main_menu()
    _update_mouse()


func quit_game() -> void:
    if in_game:
        _save_progress()
    get_tree().quit()


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        quit_game()


func _unhandled_input(event: InputEvent) -> void:
    if not in_game:
        return
    if event.is_action_pressed("pause"):
        if is_paused:
            resume()
        elif ui.phone_open:
            set_phone(false)
        else:
            pause_game()
    elif is_paused:
        return
    elif event.is_action_pressed("phone"):
        set_phone(not ui.phone_open)
    elif event.is_action_pressed("map"):
        set_phone(true, "map")
    elif event.is_action_pressed("interact"):
        var it := current_interaction()
        if it.has("fn"):
            it.fn.call()


func current_interaction() -> Dictionary:
    var m: Dictionary = Game.mission
    var p := player.global_position
    var st: String = m.get("state", "")
    if st == "to_pickup":
        var r: Dictionary = world.poi(m.ri, m.rj)
        if _near(p, r.door, 10.0):
            if absf(player.speed) < 3.0:
                return {"text": "E — איסוף משלוח מ%s" % r.name, "fn": _do_pickup}
            return {"text": "האט כדי לאסוף את ההזמנה"}
    elif st == "to_customer":
        var h: Dictionary = world.poi(m.hi, m.hj)
        if _near(p, h.door, 10.0):
            if absf(player.speed) < 3.0:
                return {"text": "E — השאר ליד הדלת" if bool(m.leave) else "E — מסירת המשלוח", "fn": _do_deliver}
            return {"text": "האט כדי למסור את ההזמנה"}
    var b: Dictionary = world.poi(clampi(floori(p.x / World.S), 0, World.N - 1), clampi(floori(p.z / World.S), 0, World.N - 1))
    if b.kind == "bank" and _near(p, b.door, 9.0):
        return {"text": "E — כספומט: %s" % b.name, "fn": func(): set_phone(true, "bank")}
    return {}


func _near(a: Vector3, b: Vector3, r: float) -> bool:
    return Vector2(a.x - b.x, a.z - b.z).length() < r


func _do_pickup() -> void:
    player.play_pickup()
    Game.pickup()


func _do_deliver() -> void:
    var m: Dictionary = Game.mission
    var h: Dictionary = world.poi(m.hi, m.hj)
    var leave := bool(m.leave)
    var summary := Game.complete_mission()
    if summary.is_empty():
        return
    player.drop_bag()
    if leave:
        var bm := MeshInstance3D.new()
        var b := BoxMesh.new()
        b.size = Vector3(0.3, 0.3, 0.16)
        bm.mesh = b
        var mt := StandardMaterial3D.new()
        mt.albedo_color = Color("111111")
        bm.material_override = mt
        add_child(bm)
        bm.global_position = h.door + Vector3(-1.0, 0.15, -1.2)
        get_tree().create_timer(8.0).timeout.connect(bm.queue_free)
    elif customer != null and is_instance_valid(customer):
        customer.pose_receive()
        var c := customer
        customer = null
        var tw := c.create_tween()
        tw.tween_interval(2.0)
        tw.tween_property(c, "position", c.position + Vector3(0, 0, -3.0), 1.5)
        tw.tween_callback(c.queue_free)
    ui.show_summary(summary)


func _process(delta: float) -> void:
    if customer != null and is_instance_valid(customer):
        customer.pose_stand(0.0, 0.0)
    if not in_game or is_paused or player == null:
        return
    world.update_streaming(player.global_position, player.velocity)
    Game.tick(delta)
    if Game.mission.is_empty():
        _offer_t -= delta
        if _offer_t <= 0.0:
            Game.new_offer()
            _offer_t = randf_range(15.0, 30.0)
    _pos_t += delta
    if _pos_t > 4.0:
        _pos_t = 0.0
        if player.is_on_floor():
            Game.last_pos = player.global_position
    _save_t += delta
    if _save_t > 45.0:
        _save_t = 0.0
        _save_progress()
    var it := current_interaction()
    ui.set_prompt(str(it.get("text", "")))
    ui.update_hud(player, world)
    if marker.visible:
        marker.rotation.y += delta
