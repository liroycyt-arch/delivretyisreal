class_name MapView
extends Control
## מפה מצוירת: מפה מלאה (range_m = 0) או מיני-מפה העוקבת אחרי השחקן.

signal picked(poi)

var world = null
var player = null
var range_m := 0.0
var selectable := false
var selected := {}


func _ready() -> void:
    clip_contents = true
    mouse_filter = Control.MOUSE_FILTER_STOP if selectable else Control.MOUSE_FILTER_IGNORE


func _process(_d: float) -> void:
    if is_visible_in_tree():
        queue_redraw()


func _cs() -> Array:
    if range_m > 0.0 and player != null:
        return [Vector2(player.global_position.x, player.global_position.z), size.x * 0.5 / range_m]
    return [Vector2(World.SIZE * 0.5 - 40.0, World.SIZE * 0.5), minf(size.x, size.y) / (World.SIZE + 260.0)]


func _s(x: float, z: float, c: Vector2, sc: float) -> Vector2:
    return size * 0.5 + (Vector2(x, z) - c) * sc


func _rect(x0: float, z0: float, x1: float, z1: float, col: Color, c: Vector2, sc: float) -> void:
    var a := _s(x0, z0, c, sc)
    var b := _s(x1, z1, c, sc)
    draw_rect(Rect2(a, b - a), col)


func _draw() -> void:
    if world == null:
        return
    var cs := _cs()
    var c: Vector2 = cs[0]
    var sc: float = cs[1]
    var N := World.N
    var S := World.S
    draw_rect(Rect2(Vector2.ZERO, size), Color(0.09, 0.11, 0.14, 0.95))
    _rect(-600, -300, -90, World.SIZE + 300, Color("2a7fb8"), c, sc)
    _rect(-90, -300, -7, World.SIZE + 300, Color("c9b88a"), c, sc)
    var lw := maxf(1.5, World.R * sc)
    for i in range(N + 1):
        var col := Color("e08a3a") if World.ONEWAY_V.has(i) else Color("5b6068")
        draw_line(_s(i * S, 0, c, sc), _s(i * S, World.SIZE, c, sc), col, lw)
    for j in range(N + 1):
        var col := Color("e08a3a") if World.ONEWAY_H.has(j) else Color("5b6068")
        draw_line(_s(0, j * S, c, sc), _s(World.SIZE, j * S, c, sc), col, lw)
    var font := get_theme_default_font()
    for i in range(N):
        for j in range(N):
            var p: Dictionary = world.poi(i, j)
            if p.kind == "home":
                continue
            var col := Color("f39c12") if p.kind == "restaurant" else (Color("3498db") if p.kind == "bank" else Color("b46cff"))
            var pos := _s(p.door.x, p.door.z, c, sc)
            draw_rect(Rect2(pos - Vector2(3, 3), Vector2(6, 6)), col)
            if p.kind == "landmark" and (range_m == 0.0 or range_m > 0.0):
                draw_string(font, pos + Vector2(-40, -6), p.name, HORIZONTAL_ALIGNMENT_CENTER, 80, 12, Color.WHITE)
    var cw := World.CHUNK * S
    for cx in range(N / World.CHUNK):
        for cz in range(N / World.CHUNK):
            if not world.chunks.has(Vector2i(cx, cz)):
                _rect(cx * cw, cz * cw, (cx + 1) * cw, (cz + 1) * cw, Color(0, 0, 0, 0.35), c, sc)
    var m: Dictionary = Game.mission
    if not m.is_empty() and m.state == "to_pickup":
        var r: Dictionary = world.poi(m.ri, m.rj)
        draw_circle(_s(r.door.x, r.door.z, c, sc), 7.0, Color("ffd600"))
    elif not m.is_empty() and m.state == "to_customer":
        var h: Dictionary = world.poi(m.hi, m.hj)
        draw_circle(_s(h.door.x, h.door.z, c, sc), 7.0, Color("2ecc71"))
    if Game.nav_active and Game.nav_route.size() > 1:
        var pts := PackedVector2Array()
        for v in Game.nav_route:
            pts.append(_s(v.x, v.z, c, sc))
        draw_polyline(pts, Color("4dd0ff"), 4.0)
        draw_circle(pts[pts.size() - 1], 6.0, Color("ff4d4d"))
    if not selected.is_empty():
        draw_arc(_s(selected.door.x, selected.door.z, c, sc), 9.0, 0, TAU, 20, Color.WHITE, 2.0)
    if player != null:
        var pp := _s(player.global_position.x, player.global_position.z, c, sc)
        var h: float = player.heading
        var f := Vector2(-sin(h), -cos(h))
        var r := Vector2(-f.y, f.x)
        draw_colored_polygon(PackedVector2Array([pp + f * 11.0, pp - f * 7.0 + r * 6.0, pp - f * 7.0 - r * 6.0]), Color("ffd600"))


func _gui_input(event: InputEvent) -> void:
    if not selectable or world == null:
        return
    if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        var cs := _cs()
        var c: Vector2 = cs[0]
        var sc: float = cs[1]
        var w: Vector2 = (event.position - size * 0.5) / sc + c
        var bi := floori(w.x / World.S)
        var bj := floori(w.y / World.S)
        if bi >= 0 and bj >= 0 and bi < World.N and bj < World.N:
            selected = world.poi(bi, bj)
            picked.emit(selected)
